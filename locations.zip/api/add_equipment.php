<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/auth.php';
auth_require_role('Admin', true);

require_once __DIR__ . '/../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Only POST requests are allowed.']);
    exit;
}

$name = isset($_POST['name']) ? trim($_POST['name']) : '';
$categoryId = isset($_POST['category']) ? (int)$_POST['category'] : 0;
$locationId = isset($_POST['location']) ? (int)$_POST['location'] : 0;
$returnLocationId = isset($_POST['return_location']) ? (int)$_POST['return_location'] : 0;
$returnLocationId = $returnLocationId > 0 ? $returnLocationId : null;

require_once __DIR__ . '/auth_helper.php';
auth_ensure_locations_table_exists($connection);
auth_ensure_categories_table_exists($connection);

// Fetch allowed locations from DB
$locationResult = $connection->query('SELECT id, name FROM locations ORDER BY name');
$allowedLocationIds = [];
if ($locationResult) {
    while ($row = $locationResult->fetch_assoc()) {
        $allowedLocationIds[] = (int)$row['id'];
    }
    $locationResult->free();
}

// Fetch allowed categories from DB
$categoryResult = $connection->query('SELECT id, name FROM categories ORDER BY name');
$allowedCategoryIds = [];
if ($categoryResult) {
    while ($row = $categoryResult->fetch_assoc()) {
        $allowedCategoryIds[] = (int)$row['id'];
    }
    $categoryResult->free();
}

if ($name === '' || $categoryId <= 0 || $locationId <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Name, category, and location are required.']);
    exit;
}

if ($returnLocationId !== null && !in_array($returnLocationId, $allowedLocationIds, true)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid return location selected.']);
    exit;
}

if (!in_array($locationId, $allowedLocationIds, true)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid location selected.']);
    exit;
}


$columnCheck = $connection->query("SHOW COLUMNS FROM equipment LIKE 'location'");
if ($columnCheck && $columnCheck->num_rows === 0) {
    $connection->query("ALTER TABLE equipment ADD COLUMN location VARCHAR(100) NULL AFTER status");
}
$returnColumnCheck = $connection->query("SHOW COLUMNS FROM equipment LIKE 'return_location'");
if ($returnColumnCheck && $returnColumnCheck->num_rows === 0) {
    $connection->query("ALTER TABLE equipment ADD COLUMN return_location VARCHAR(100) NULL AFTER location");
}

// Prevent duplicate equipment names
$checkSql = 'SELECT id FROM equipment WHERE name = ? LIMIT 1';
$checkStmt = $connection->prepare($checkSql);
if ($checkStmt === false) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to prepare duplicate check: ' . $connection->error]);
    exit;
}
$checkStmt->bind_param('s', $name);
$checkStmt->execute();
$checkStmt->store_result();
if ($checkStmt->num_rows > 0) {
    $checkStmt->close();
    http_response_code(409);
    echo json_encode(['success' => false, 'error' => 'An equipment item with that name already exists.']);
    exit;
}
$checkStmt->close();

$status = 'AVAILABLE';
$assignedTo = null;

$insertSql = 'INSERT INTO equipment (name, category, status, location, return_location, assigned_to) VALUES (?, ?, ?, ?, ?, ?)';
$stmt = $connection->prepare($insertSql);
if ($stmt === false) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to prepare insert statement: ' . $connection->error]);
    exit;
}

$stmt->bind_param('sisiss', $name, $categoryId, $status, $locationId, $returnLocationId, $assignedTo);
if (!$stmt->execute()) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Insert failed: ' . $stmt->error]);
    $stmt->close();
    exit;
}

$insertId = $stmt->insert_id;
$stmt->close();

$qrCode = 'equipment_id=' . $insertId;
$updateSql = 'UPDATE equipment SET qr_code = ? WHERE id = ?';
$stmt = $connection->prepare($updateSql);
if ($stmt === false) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to prepare update statement: ' . $connection->error]);
    exit;
}

$stmt->bind_param('si', $qrCode, $insertId);
if (!$stmt->execute()) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Update failed: ' . $stmt->error]);
    $stmt->close();
    exit;
}

$stmt->close();
$connection->close();

// Handle image upload if provided
$imagePath = null;
if (!empty($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
    $file = $_FILES['image'];
    $allowedMimeTypes = [
        'image/jpeg' => 'jpg',
        'image/pjpeg' => 'jpg',
        'image/png' => 'png',
    ];

    if ($file['size'] > 2 * 1024 * 1024) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'File size must be 2MB or less.']);
        exit;
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mimeType = $finfo->file($file['tmp_name']);
    if (!isset($allowedMimeTypes[$mimeType])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Only JPG and PNG images are allowed.']);
        exit;
    }

    $extension = $allowedMimeTypes[$mimeType];
    $uploadDir = __DIR__ . '/../uploads/equipment/';
    if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true)) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Unable to create upload directory.']);
        exit;
    }

    $filename = time() . '_' . bin2hex(random_bytes(8)) . '.' . $extension;
    $destination = $uploadDir . $filename;

    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Failed to move uploaded file.']);
        exit;
    }

    $imagePath = 'uploads/equipment/' . $filename;

    // Update the equipment with the image path
    require_once __DIR__ . '/../config/pdo.php';
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    try {
        $columnCheck = $pdo->query("SHOW COLUMNS FROM equipment LIKE 'image'");
        if ($columnCheck->fetch(PDO::FETCH_ASSOC) === false) {
            $pdo->exec("ALTER TABLE equipment ADD COLUMN image VARCHAR(255) NULL AFTER qr_code");
        }

        $updateStmt = $pdo->prepare('UPDATE equipment SET image = :image WHERE id = :id');
        $updateStmt->execute([
            ':image' => $imagePath,
            ':id' => $insertId,
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
        exit;
    }
}

echo json_encode([
    'success' => true,
    'data' => [
        'id' => $insertId,
        'qr_code' => $qrCode,
    ],
]);
?>