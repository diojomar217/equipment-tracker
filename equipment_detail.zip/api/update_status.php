<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/auth.php';
auth_require_role(['Admin', 'Staff'], true);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/notifications_helper.php';
ensure_equipment_status_updated_at_column($connection);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Only POST requests are allowed.']);
    exit;
}

$id = isset($_POST['id']) ? trim($_POST['id']) : '';
$action = isset($_POST['status']) ? trim($_POST['status']) : '';
$location = isset($_POST['location']) ? trim($_POST['location']) : '';
$currentUser = auth_user()['username'] ?? '';

$allowedActions = ['BORROW', 'RETURN', 'MAINTENANCE'];
$allowedLocations = ['Room 101', 'Storage', 'Office', 'Lab'];

// Fetch allowed locations from DB
$locationResult = $connection->query('SELECT name FROM locations ORDER BY name');
$allowedLocations = [];
if ($locationResult) {
    while ($row = $locationResult->fetch_assoc()) {
        $allowedLocations[] = $row['name'];
    }
    $locationResult->free();
}

if ($id === '' || $action === '' || $currentUser === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'id and action are required.']);
    exit;
}

if ($location !== '' && !in_array($location, $allowedLocations, true)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid location selected.']);
    exit;
}

if (!filter_var($id, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid equipment ID.']);
    exit;
}

if (!in_array($action, $allowedActions, true)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid action value.']);
    exit;
}

if ($action === 'MAINTENANCE' && auth_user()['role'] !== 'Admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Only admins can send equipment to maintenance.']);
    exit;
}

$selectSql = 'SELECT status, assigned_to FROM equipment WHERE id = ? LIMIT 1';
$stmt = $connection->prepare($selectSql);
if ($stmt === false) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to prepare select statement: ' . $connection->error]);
    exit;
}
$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result();
$currentData = $result ? $result->fetch_assoc() : null;
$stmt->close();

if (!$currentData) {
    http_response_code(404);
    echo json_encode(['success' => false, 'error' => 'Equipment not found.']);
    exit;
}

$currentStatus = $currentData['status'];
$currentAssignedTo = $currentData['assigned_to'];
$assignedTo = null;
$newStatus = '';
$newLocation = null;

if ($action === 'BORROW') {
    if ($currentStatus !== 'AVAILABLE') {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Equipment must be available before it can be borrowed.']);
        exit;
    }
    if ($location === '') {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Location is required when borrowing equipment.']);
        exit;
    }
    $newStatus = 'BORROWED';
    $assignedTo = $currentUser;
    $newLocation = $location;
} elseif ($action === 'RETURN') {
    if ($currentStatus !== 'BORROWED' || $currentAssignedTo !== $currentUser) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Only the user who borrowed the equipment can return it.']);
        exit;
    }
    $newStatus = 'AVAILABLE';
    $assignedTo = null;
} elseif ($action === 'MAINTENANCE') {
    if ($currentStatus === 'MAINTENANCE') {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Equipment is already in maintenance.']);
        exit;
    }
    $newStatus = 'MAINTENANCE';
    $assignedTo = null;
}

if ($assignedTo === null) {
    if ($newLocation !== null) {
        $updateSql = 'UPDATE equipment SET status = ?, assigned_to = NULL, location = ?, status_updated_at = NOW() WHERE id = ?';
        $stmt = $connection->prepare($updateSql);
        if ($stmt === false) {
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Failed to prepare update statement: ' . $connection->error]);
            exit;
        }
        $stmt->bind_param('ssi', $newStatus, $newLocation, $id);
    } else {
        $updateSql = 'UPDATE equipment SET status = ?, assigned_to = NULL, status_updated_at = NOW() WHERE id = ?';
        $stmt = $connection->prepare($updateSql);
        if ($stmt === false) {
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Failed to prepare update statement: ' . $connection->error]);
            exit;
        }
        $stmt->bind_param('si', $newStatus, $id);
    }
} else {
    if ($newLocation !== null) {
        $updateSql = 'UPDATE equipment SET status = ?, assigned_to = ?, location = ?, status_updated_at = NOW() WHERE id = ?';
        $stmt = $connection->prepare($updateSql);
        if ($stmt === false) {
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Failed to prepare update statement: ' . $connection->error]);
            exit;
        }
        $stmt->bind_param('sssi', $newStatus, $assignedTo, $newLocation, $id);
    } else {
        $updateSql = 'UPDATE equipment SET status = ?, assigned_to = ?, status_updated_at = NOW() WHERE id = ?';
        $stmt = $connection->prepare($updateSql);
        if ($stmt === false) {
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Failed to prepare update statement: ' . $connection->error]);
            exit;
        }
        $stmt->bind_param('ssi', $newStatus, $assignedTo, $id);
    }
}

if (!$stmt->execute()) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Status update failed: ' . $stmt->error]);
    $stmt->close();
    exit;
}

if ($stmt->affected_rows === 0) {
    $stmt->close();
    echo json_encode(['success' => false, 'error' => 'No equipment record updated.']);
    exit;
}

$stmt->close();

$logSql = 'INSERT INTO logs (equipment_id, action, user, created_at) VALUES (?, ?, ?, NOW())';
$stmt = $connection->prepare($logSql);
if ($stmt === false) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to prepare log insert statement: ' . $connection->error]);
    exit;
}

$stmt->bind_param('iss', $id, $action, $currentUser);
if (!$stmt->execute()) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Log insert failed: ' . $stmt->error]);
    $stmt->close();
    exit;
}

$stmt->close();
$connection->close();

echo json_encode(['success' => true, 'message' => 'Equipment status updated successfully.']);
?>