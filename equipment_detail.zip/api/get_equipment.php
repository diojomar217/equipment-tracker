<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/auth.php';
auth_require_role(['Admin', 'Staff'], true);

require_once __DIR__ . '/../config/db.php';

$columnCheck = $connection->query("SHOW COLUMNS FROM equipment LIKE 'location'");
if ($columnCheck && $columnCheck->num_rows === 0) {
    $connection->query("ALTER TABLE equipment ADD COLUMN location VARCHAR(100) NULL AFTER status");
}

$allowedLocations = ['Room 101', 'Storage', 'Office', 'Lab'];

// Fetch allowed locations from DB
$locationResult = $connection->query('SELECT name FROM locations ORDER BY name');
$allowedLocations = [];
if ($locationResult) {
    while ($row = $locationResult->fetch_assoc()) {
        $allowedLocations[] = $row['name'];
    }
    $locationResult->free();
}

$location = isset($_GET['location']) ? trim($_GET['location']) : '';
$status = isset($_GET['status']) ? trim($_GET['status']) : '';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$assigned_to = isset($_GET['assigned_to']) ? trim($_GET['assigned_to']) : '';

$conditions = [];
$params = [];
$types = '';

if ($location !== '' && in_array($location, $allowedLocations, true)) {
    $conditions[] = 'location = ?';
    $params[] = $location;
    $types .= 's';
}

if ($status !== '') {
    $conditions[] = 'status = ?';
    $params[] = $status;
    $types .= 's';
}

if ($assigned_to !== '') {
    $conditions[] = 'assigned_to = ?';
    $params[] = $assigned_to;
    $types .= 's';
}

$sql = 'SELECT * FROM equipment';
if (!empty($conditions)) {
    $sql .= ' WHERE ' . implode(' AND ', $conditions);
}
if ($search !== '') {
    $searchCondition = $sql . (empty($conditions) ? ' WHERE' : ' AND') . ' (name LIKE ? OR category LIKE ?)';
    $sql = $searchCondition;
    $params[] = '%' . $search . '%';
    $params[] = '%' . $search . '%';
    $types .= 'ss';
}
$sql .= ' ORDER BY id DESC';

$stmt = $connection->prepare($sql);
if ($stmt === false) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Database query failed: ' . $connection->error,
    ]);
    exit;
}

if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

if ($result === false) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Database query failed: ' . $connection->error,
    ]);
    exit;
}

$equipment = [];
while ($row = $result->fetch_assoc()) {
    $equipment[] = $row;
}

echo json_encode([
    'success' => true,
    'data' => $equipment,
]);

$connection->close();
?>